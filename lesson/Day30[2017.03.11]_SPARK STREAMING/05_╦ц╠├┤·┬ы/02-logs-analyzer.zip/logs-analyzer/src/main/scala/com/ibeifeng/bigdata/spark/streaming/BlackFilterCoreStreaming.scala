package com.ibeifeng.bigdata.spark.streaming

import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.dstream.{DStream, ReceiverInputDStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

/**
 * Created by XuanYu on 2017/3/12.
 */
object BlackFilterCoreStreaming {

  def main(args: Array[String]) {
    val sparkConf = new SparkConf()
      .setAppName("WordCountStreaming Application")
      .setMaster(args(0))  // 通过参数传递

    val sc = SparkContext.getOrCreate(sparkConf)

    // Seconds(5)代表的是 每次处理多长时间范围内的数据
    // 批次时间间隔:batch interval
    val ssc = new StreamingContext(sc, Seconds(5))

    // Create a DStream that will connect to hostname:port, like localhost:9999
    val inputDStream: ReceiverInputDStream[String] = ssc
            .socketTextStream("hadoop-senior01.ibeifeng.com", 9999)

    // 数据格式：datetime	adid	userid	ip，中间使用制表符隔开
    val userIdDStream: DStream[(Int, String)] = inputDStream
        .map(line => (line.split("\t")(2).toInt, line))


    // 黑名单用户
    val list = List(10001, 11012, 20987, 30982)
    // 使用广播变量
    val listBroadCast = sc.broadcast(list)   // 有问题，仅仅样式代码，需要参考官方文档
    // http://spark.apache.org/docs/1.6.1/streaming-programming-guide.html#accumulators-and-broadcast-variables

    /**
     * 要进行黑名单用户的过滤
     *
     * def transform[U: ClassTag](transformFunc: RDD[T] => RDD[U]): DStream[U]
     */
    userIdDStream.transform(rdd => {
      // TODO: 当然SparkStreaming与SparkSQL集成也是在此完成的，只要将RDD转换为DataFrame即可，可使用
      // TODO: SQL语句或者DSL语句进行分析处理
      val filterRdd: RDD[(Int, String)] = rdd.filter{
        case (userId, log) => !listBroadCast.value.contains(userId)  // 黑名单中不包含的数据，才符合要求
      }
      // return
      filterRdd
    })



    ssc.start()             // Start the computation
    ssc.awaitTermination()  // Wait for the computation to terminate

    // SparkStreaming Stop
    ssc.stop()    // 包含  sc.stop()
  }

}
