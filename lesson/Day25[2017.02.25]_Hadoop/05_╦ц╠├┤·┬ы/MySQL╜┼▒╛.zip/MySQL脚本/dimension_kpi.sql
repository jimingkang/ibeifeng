/*
Navicat MySQL Data Transfer

Source Server         : 192.168.187.128
Source Server Version : 50626
Source Host           : 192.168.187.131:3306
Source Database       : report

Target Server Type    : MYSQL
Target Server Version : 50626
File Encoding         : 65001

Date: 2016-09-07 21:41:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `dimension_kpi`
-- ----------------------------
DROP TABLE IF EXISTS `dimension_kpi`;
CREATE TABLE `dimension_kpi` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `kpi_name` varchar(45) DEFAULT NULL COMMENT 'kpi名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dimension_kpi
-- ----------------------------
