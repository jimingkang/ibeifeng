/*
Navicat MySQL Data Transfer

Source Server         : 192.168.187.128
Source Server Version : 50626
Source Host           : 192.168.187.128:3306
Source Database       : report

Target Server Type    : MYSQL
Target Server Version : 50626
File Encoding         : 65001

Date: 2016-09-07 16:42:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `dimension_event`
-- ----------------------------
DROP TABLE IF EXISTS `dimension_event`;
CREATE TABLE `dimension_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'event维度主键id',
  `category` varchar(45) NOT NULL COMMENT '事件种类名称',
  `action` varchar(45) NOT NULL COMMENT '事件动作名称',
  `origin_id` int(11) DEFAULT '0' COMMENT '起源id，父id；0表示没有起源，属于事件流的第一个事件',
  `has_multi_children` int(1) DEFAULT '0' COMMENT '0表示不允许有多个子事件；1表示允许; 子事件类型必须一样',
  `flow_id` int(11) DEFAULT NULL COMMENT '事件流id',
  `seq` int(11) DEFAULT NULL COMMENT '当前事件在时间流中所述步骤序列号，事件流中该序号可以有重复的存在',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dimension_event
-- ----------------------------
INSERT INTO `dimension_event` VALUES ('1', '搜索事件流', '搜索', '0', '0', '1', '1');
INSERT INTO `dimension_event` VALUES ('2', '搜索事件流', '浏览搜索页面', '1', '0', '1', '2');
INSERT INTO `dimension_event` VALUES ('3', '搜索事件流', '点击查看详情页', '2', '1', '1', '3');
INSERT INTO `dimension_event` VALUES ('4', '搜索事件流', '详情页面浏览事件', '3', '0', '1', '4');
INSERT INTO `dimension_event` VALUES ('5', '搜索事件流', '点击立即购买事件', '4', '0', '1', '5');
