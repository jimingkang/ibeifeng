package com.ibeifeng.bigdata.spark

/**
 * Created by XuanYu on 2017/3/4.
 */
object HelloWorld {

  def main(args: Array[String]) {
    println("Hello World!!!!!!!!!!")
  }

}
