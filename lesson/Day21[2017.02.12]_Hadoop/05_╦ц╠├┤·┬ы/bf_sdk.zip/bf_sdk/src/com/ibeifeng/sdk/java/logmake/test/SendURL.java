package com.ibeifeng.sdk.java.logmake.test;

import com.ibeifeng.sdk.java.logmake.AnalyticsEngineSDK;

public class SendURL {
	public static void main(String[] args) {
		AnalyticsEngineSDK.onChargeSuccess("123", "456");
		AnalyticsEngineSDK.onChargeRefund("456", "123");
	}
}
