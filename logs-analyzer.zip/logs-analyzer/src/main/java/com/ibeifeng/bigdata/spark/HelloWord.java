package com.ibeifeng.bigdata.spark;

/**
 * Created by XuanYu on 2017/3/11.
 */
public class HelloWord {

    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
